<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->load->view('cokluveriekleme_view');
	}


	public function cokluveriekledata(){

		if($this->input->method() == "post"){

			foreach($this->input->post('baslik') as $row){

				$ekle = $this->common_model->addata('veriler',[
					'baslik' => $row
				]);

			}

			if($ekle){
				echo "Veriler eklendi";
			}else{
				echo "Hata oluştu";
			}

		}

	}

	public function listelesil(){
		$viewData = array(
			"veriler" => $this->common_model->getAll([],'veriler')
		);
		$this->load->view('cokluverisil_view',$viewData);
	}


	public function listeleduzenle(){
		$viewData = array(
			"veriler" => $this->common_model->getAll([],'veriler')
		);
		$this->load->view('cokluveriduzenle_view',$viewData);
	}

	public function listelesildata(){
		if($this->input->method() == "post"){
			
			$sil = $this->input->post('baslik');
			$birlestir = implode(',',$sil);
			$sonuc = $this->db->query("DELETE FROM veriler WHERE id IN($birlestir)");
			if($sonuc){
				echo "veriler silindi";
			}else{
				echo "Hata oluştu";
			}
		}
	}

	public function listeleduzenledata(){
		if($this->input->method() == "post"){
			
			$viewData = array(
				"duzenlenenler" => $this->db->where_in('id',$this->input->post('baslik'))->get('veriler')->result()
			);

			$this->load->view('cokluveriduzenleformu_view',$viewData);

		}
	}

	public function listeleduzenledb(){

		if($this->input->method() == "post"){
			
			$veriid = $this->input->post('veriid',true);
			$baslik = $this->input->post('baslik',true);

			for($i = 0; $i < count($veriid); $i++){

				$guncelle = $this->common_model->update(['id'=>$veriid[$i]],['baslik'=>$baslik[$i]],'veriler');

			}
			if($guncelle){
				echo "seçilen veriler güncellendi";
			}else{
				echo "hata oluştu";
			}

		}

	}
}
