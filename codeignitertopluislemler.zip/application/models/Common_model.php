<?php 

class Common_model extends CI_Model{

    public function addata($table,$data){
        return $this->db->insert($table,$data);
    }

    public function update($where,$data,$table){
        return $this->db->where($where)->update($table,$data);
    }

    public function getAll($where,$table){
        return $this->db->where($where)->get($table)->result();
    }

}

?>