<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<a href="<?php echo base_url('home/listelesil'); ?>">Çoklu veri sil</a> | <a href="<?php echo base_url('home/listeleduzenle');?>">Çoklu veri düzenle</a>
<br><br>
<form action="<?php echo base_url('home/cokluveriekledata');?>" method="POST">
<input type="text" name="baslik[]" placeholder="Başlık giriniz" /><br>
<input type="text" name="baslik[]" placeholder="Başlık giriniz" /><br>
<input type="text" name="baslik[]" placeholder="Başlık giriniz" /><br>
<button type="submit">Çoklu veri ekle</button>
</form>