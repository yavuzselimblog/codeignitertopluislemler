<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<form action="<?php echo base_url('home/listeleduzenledb');?>" method="POST">
<?php foreach($duzenlenenler as $pow){ ?>
    <input type="text" name="baslik[]" value="<?php echo $pow->baslik;?>" /><br>
    <input type="hidden" name="veriid[]" value="<?php echo $pow->id;?>" /><br>
<?php } ?>
<button type="submit">Verileri güncelle</button>
</form>