<form action="<?php echo base_url('home/listelesildata');?>" method="POST">
<table border=1>
<thead>
    <th>SEÇİM</th>
    <th>BAŞLIK</th>
</thead>
    <tbody>
    <?php foreach($veriler as $row){ ?>
        <tr>
            <td><input type="checkbox" name="baslik[]" value="<?php echo $row->id;?>"/></td>
            <td><?php echo $row->baslik;?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
<button type="submit">Çoklu veri sil</button>
</form>